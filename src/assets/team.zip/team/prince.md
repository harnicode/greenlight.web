Prince Sampong Owusu
Director of Green Light Sports Consult.
He is Results-oriented professional with experience in managing and direction.Possesses excellent time management skills,top customer-relations abilities.With years of experience in banking(Corporate & Investment Banking) and as an Entreprenuer he is passionate about leveraging leadership skills to inspire teams and drive business success.
He holds master’s degree in Business Administration,a First Degree from University of Ghana,Legon and a Product of St Peter’s Secondary School,Nkwatia-Kwahu.
