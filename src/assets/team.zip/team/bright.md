A seasoned soccer enthusiasts with great insight in talent identification and scouting, is committed in unearthing and developing talent. Bright Abodakpi, Scout
